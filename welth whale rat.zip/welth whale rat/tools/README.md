![whalestealer_1](https://github.com/MehdiKamber/whalestealer/assets/150480101/30a367ff-0bb3-4985-9e26-47609ccba12a)

![whalestealer_2](https://github.com/MehdiKamber/whalestealer/assets/150480101/ea408248-1abb-48e2-9634-2b74d8f61963)

## LIBRARIES
```markdown
     socket base64 shutil zipfile sqlite3 pycrypto subprocess win32crypt pycryptodome customtkinter
```

## SOCIAL
```markdown
                                             t.me/whalestealer
```
